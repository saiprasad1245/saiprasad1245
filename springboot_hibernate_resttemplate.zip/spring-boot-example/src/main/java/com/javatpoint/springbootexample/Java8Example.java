package com.javatpoint.springbootexample;

@FunctionalInterface
public interface Java8Example {

	void display();
	
	default void print() {
		System.out.println("default method in Java8Example");
	}
	
	static void utility() {
		System.out.println("static method default method in Java8Example");
	}
}
