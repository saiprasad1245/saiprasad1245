package com.javatpoint.springbootexample.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController()
public class DisplayController {

	@Value("${server.port}")
	private String serverport;
	
	@Autowired
	private RestTemplate RestTemplate;
	@GetMapping("/message")
	public List<Object> getMessage() {
		
		
		ResponseEntity<Object[]> obj = RestTemplate.getForEntity("http://localhost:8081/products/all", Object[].class);
		
		
		return Arrays.asList(obj);
	}
	
	
	
	
}
