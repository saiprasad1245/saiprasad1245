package com.javatpoint.springbootexample;

public class RoundedShapeFactory extends AbstractFactory{

	@Override
	public Shape getShape(String shapeType) {
		if("roundedSquare".equalsIgnoreCase(shapeType)) {
			return new RoundedSquare();
		}
		if("roundedCircle".equalsIgnoreCase(shapeType)) {
			return new RoundedCircle();
		}
		
		return null;
		// TODO Auto-generated method stub
		
	}

}
