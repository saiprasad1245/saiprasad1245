package com.javatpoint.springbootexample;

public class FlyweigtFactory {

	static String colors[] = {"pink","red","greem"};
	public static void main(String[] args) {
		
		for(int i=0;i<20;i++) {
			
			Circle2 c = (Circle2) CircleShapeFactory.getCircle(getRandomColor());
			c.draw();
		}
	}
	
	private static String getRandomColor() {
		
		return colors[(int)(Math.random()*colors.length)];
	}
}
