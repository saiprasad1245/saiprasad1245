package com.javatpoint.springbootexample.controller;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.endpoint.annotation.WriteOperation;
import org.springframework.stereotype.Component;

@Component
@Endpoint(id = "customActuator")
public class CustomActuator {

	@ReadOperation
	public String currentDBDetails() {
		return "currentDBDetails";
	}
	
	@WriteOperation
	public String writeDBDetails() {
		return "writeDBDetails";
	}
}
