package com.javatpoint.springbootexample;

public class RoundedSquare implements Shape {

	@Override
	public void draw() {
		System.out.println("in Rounded Square draw class");
		
	}

}
