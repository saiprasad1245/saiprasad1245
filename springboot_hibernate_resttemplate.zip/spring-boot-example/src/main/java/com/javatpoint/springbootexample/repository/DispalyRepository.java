package com.javatpoint.springbootexample.repository;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.javatpoint.springbootexample.controller.Product;

@Repository
public interface DispalyRepository extends JpaRepository<Product, Long>{
	
	@Query(value = "FROM Product p WHERE p.name = 'sai'")
			List<Product> findQueryByName();
	
}
