package com.javatpoint.springbootexample.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.javatpoint.springbootexample.service.DispalyService;

@RestController
public class ProductServiceController{
   
   @Autowired
   private DispalyService service;
   
   @RequestMapping(value = "/products/{id}", method = RequestMethod.GET)
   public List<Product> updateProduct(@PathVariable("id") int id) { 
     
      List<Product> list = service.getProductDetails();
      
      List<Product> list1  = list.stream().filter(x->x.getId()==id).collect(Collectors.toList());
      
      if(list1.isEmpty())
    	  throw new ProductNotfoundException();
      
      return list1;
   }
   
   @GetMapping(value = "/products/all")
   public List<Product> getProducts() { 
     
      List<Product> list = service.getNamedQueries();
      
     
      
      if(list.isEmpty())
    	  throw new ProductNotfoundException();
      
      return list;
   }
}