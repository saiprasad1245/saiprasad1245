package com.javatpoint.springbootexample;

public class FactoryProducer {

	public static AbstractFactory getFactory(boolean isrounded) {
		
		if(isrounded) {
			return new RoundedShapeFactory();
			
		}else {
			return new ShapeFactory2();
		}
		
	}
	
}
