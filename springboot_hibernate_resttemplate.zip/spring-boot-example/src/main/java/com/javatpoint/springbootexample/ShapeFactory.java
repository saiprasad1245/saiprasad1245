package com.javatpoint.springbootexample;

public class ShapeFactory {

	public Shape getShape(String shapeType) {
		if("circle".equals(shapeType)) {
			return new Circle();
		}
		
		if("Square".equals(shapeType)) {
			return new Square();
		}
		return null;
	}
	
}
