package com.javatpoint.springbootexample;

public class Circle implements Shape {

	@Override
	public void draw() {
		System.out.println("in circle draw class");
		
	}

	
}
