package com.javatpoint.springbootexample.controller;

public class ProductNotfoundException extends RuntimeException {
	   private static final long serialVersionUID = 1L;
	}
