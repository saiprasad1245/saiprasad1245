package com.javatpoint.springbootexample;

import java.util.HashMap;

public class CircleShapeFactory {

	private static HashMap<String, Circle2> map = new HashMap<>();
	
	public static Shape getCircle(String color) {
		
		Circle2 circlemap = map.get(color);
		
		if(circlemap == null) {
			circlemap = new Circle2(color);
			map.put(color, circlemap);
			System.out.println("creating circle map");
		}
		
		
		return circlemap;
		
		
	}
}
