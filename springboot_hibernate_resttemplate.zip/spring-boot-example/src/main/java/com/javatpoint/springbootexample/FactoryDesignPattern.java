package com.javatpoint.springbootexample;

public class FactoryDesignPattern {

	public static void main(String[] args) {
		ShapeFactory sf = new ShapeFactory();
		Shape c = sf.getShape("circle");
		c.draw();
		Shape s = sf.getShape("Square");
		s.draw();
		
	}

}
