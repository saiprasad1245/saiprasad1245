package com.javatpoint.springbootexample;

public class ShapeFactory2 extends AbstractFactory{

	@Override
	public Shape getShape(String shapeType) {
		
		if("square".equalsIgnoreCase(shapeType)) {
			return new Square();
		}
		if("circle".equalsIgnoreCase(shapeType)) {
			return new Circle();
		}
		// TODO Auto-generated method stub
		return null;
		
	}

	

}
