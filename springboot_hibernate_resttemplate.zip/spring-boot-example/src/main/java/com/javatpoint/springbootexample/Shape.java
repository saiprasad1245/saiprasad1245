package com.javatpoint.springbootexample;

public interface Shape {

	void draw();
}
