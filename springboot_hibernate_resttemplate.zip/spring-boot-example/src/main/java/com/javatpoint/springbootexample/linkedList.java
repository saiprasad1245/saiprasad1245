package com.javatpoint.springbootexample;

public class linkedList {

	Node head;
	class Node{
		int data;
		Node next;
		Node(int d){
			data=d;
			next=null;
		}
	}
	
	public void rotate(int k) {
		
		if(k==0) {
			return;
		}
		
		Node current=head;
		int count=1;
		while(count<k && current!=null) {
			current = current.next;
			count++;
		}
		
		if(current == null) {
			return;
		}
		Node kthNode=current;
		
		while(current.next!=null)
			current = current.next;
		current.next=head;
		head=kthNode.next;
		kthNode.next=null;
	}
	
	public void printList() {
		
		Node temp= head;
		while(temp!=null) {
			System.out.println(temp.data);
			temp=temp.next;
		}
		System.out.println();
		
	}
	
	public void push(int data) {
		Node new_node=new Node(data);
		new_node.next=head;
		head=new_node;
	}
	
	public static void main(String[] args) {
		
		linkedList list = new linkedList();
		for(int i=60;i>0;) {
			list.push(i);
			i = i-10;
		}
		list.rotate(4);
		list.printList();
		
	}
}
