package com.javatpoint.springbootexample;

public class AbstractFactoryDesignPattern {

	public static void main(String[] args) {
		
		AbstractFactory shapef = FactoryProducer.getFactory(false);
		Shape shape1 = shapef.getShape("square");
		shape1.draw();
		Shape shape2 = shapef.getShape("circle");
		shape2.draw();
		
		AbstractFactory shapef1 = FactoryProducer.getFactory(true);
		Shape shape3 = shapef1.getShape("roundedsquare");
		shape3.draw();
		Shape shape4 = shapef1.getShape("roundedcircle");
		shape4.draw();
	}
}
