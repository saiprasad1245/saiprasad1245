package com.javatpoint.springbootexample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javatpoint.springbootexample.controller.Product;
import com.javatpoint.springbootexample.repository.DispalyRepository;

@Service
public class DispalyService {

	@Autowired
	private DispalyRepository repository;
	
	public List<Product> getProductDetails() {
		
		Product p = new Product();
		
		p.setName("sai");
		repository.save(p);
		
		return repository.findAll();
		      
		   
	}
	
	public List<Product> getNamedQueries() {
		
		
		
		return repository.findQueryByName();
		      
		   
	}
	
}
