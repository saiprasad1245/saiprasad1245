package com.javatpoint.springbootexample;

public class Java8Class implements Java8Example,Java8Example2 {

	@Override
	public void display() {
		System.out.println("in Java8Class");
		
	}

	/*
	 * @Override public void print() { // TODO Auto-generated method stub
	 * Java8Example.super.print(); }
	 */
	
	public void print() {
		System.out.println("in class print");
	}

	public static void main(String[] args) {
		
		Java8Class ex = new Java8Class();
		ex.display();
		ex.print();
		Java8Example2.utility();
	}
	
}
