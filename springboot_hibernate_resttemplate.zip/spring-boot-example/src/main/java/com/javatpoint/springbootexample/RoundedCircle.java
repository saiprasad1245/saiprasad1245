package com.javatpoint.springbootexample;

public class RoundedCircle implements Shape {

	@Override
	public void draw() {
		System.out.println("in Rounded circle draw class");
		
	}

	
}
