package com.javatpoint.springbootexample;

public class Computer {

	private String HDD;
	
	private String RAM;
	
	private boolean isGraphicsEnabled;
	
	private boolean isBluetoothEnabled;

	
	public Computer(ComputerBuilder b) {
		
		this.HDD = b.HDD;
		this.RAM = b.RAM;
		this.isGraphicsEnabled = b.isGraphicsEnabled;
		this.isBluetoothEnabled = b.isBluetoothEnabled;
	}



	public String getHDD() {
		return HDD;
	}

	

	public String getRAM() {
		return RAM;
	}

	

	public boolean isGraphicsEnabled() {
		return isGraphicsEnabled;
	}

	

	public boolean isBluetoothEnabled() {
		return isBluetoothEnabled;
	}

	
	public static class ComputerBuilder{
		private String HDD;
		
		private String RAM;
		
		private boolean isGraphicsEnabled;
		
		private boolean isBluetoothEnabled;

		public ComputerBuilder(String hDD, String rAM) {
			
			HDD = hDD;
			RAM = rAM;
		}

		public ComputerBuilder setGraphicsEnabled(boolean isGraphicsEnabled) {
			this.isGraphicsEnabled = isGraphicsEnabled;
			System.out.println("graphics set");
			return this;
		}

		public ComputerBuilder setBluetoothEnabled(boolean isBluetoothEnabled) {
			this.isBluetoothEnabled = isBluetoothEnabled;
			System.out.println("bluethoot enabled");
			return this;
		}
		
		public Computer build() {
			return new Computer(this);
		}
		
	}
	
	
	
}
