package com.javatpoint.springbootexample;

import com.javatpoint.springbootexample.Computer.ComputerBuilder;

public class BuilderPattern {

	public static void main(String[] args) {
		
		Computer c= new Computer.ComputerBuilder("500", "8GB").setBluetoothEnabled(false).setGraphicsEnabled(true).build();
		
		
	}

}
