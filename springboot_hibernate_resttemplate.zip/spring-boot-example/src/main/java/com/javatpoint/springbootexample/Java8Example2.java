package com.javatpoint.springbootexample;

@FunctionalInterface
public interface Java8Example2 {

	void display();
	
	default void print() {
		System.out.println("default method default method in Java8Example2");
	}
	
	static void utility() {
		System.out.println("static method default method in Java8Example2");
	}
}
